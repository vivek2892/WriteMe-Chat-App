//
//  ChatCell.swift
//  WriteMe
//
//  Created by VIVEK KUMAR on 9/19/17.
//  Copyright © 2017 VIVEK KUMAR. All rights reserved.
//

import UIKit

class ChatCell: UITableViewCell {

    
   
    @IBOutlet weak var contactImg: UIImageView!
   
    @IBOutlet weak var contactName: UILabel!
    @IBOutlet weak var msgDesc: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        contactImg.layer.cornerRadius = 62/2
        contactImg.layer.masksToBounds = true
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
